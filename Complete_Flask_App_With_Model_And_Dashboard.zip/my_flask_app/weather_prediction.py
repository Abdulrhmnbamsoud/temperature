
import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import joblib

# تحديد المسار الصحيح للملف
csv_file_path = os.path.join(os.path.dirname(__file__), 'weatherHistory.csv')

# التحقق مما إذا كان الملف موجودًا في المسار المحدد
if os.path.exists(csv_file_path):
    df = pd.read_csv(csv_file_path)
    print("تم تحميل الملف بنجاح.")
else:
    print(f"خطأ: الملف غير موجود في المسار: '{csv_file_path}'")

# التأكد من أن عمود التاريخ والوقت يتم تحويله إلى نوع datetime
df['Formatted Date'] = pd.to_datetime(df['Formatted Date'], errors='coerce')

# حذف أي صف يحتوي على قيم غير قابلة للتحويل
df = df.dropna(subset=['Formatted Date'])

# معالجة عمود التاريخ والوقت
df['Year'] = df['Formatted Date'].dt.year
df['Month'] = df['Formatted Date'].dt.month
df['Day'] = df['Formatted Date'].dt.day
df['Hour'] = df['Formatted Date'].dt.hour
df = df.drop(columns=['Formatted Date'])

# دالة لتدريب النموذج
def train_model():
    X = df.drop(columns=['Temperature (C)'])
    y = df['Temperature (C)']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    predictions = model.predict(X_test)
    mse = mean_squared_error(y_test, predictions)
    print(f"تم تدريب النموذج. MSE: {mse}")
    
    return model

# دالة للتنبؤ باستخدام النموذج المدرب
def predict(features):
    model_path = os.path.join(os.path.dirname(__file__), 'final_model.joblib')
    if not os.path.exists(model_path):
        model = train_model()
        joblib.dump(model, model_path)
    else:
        model = joblib.load(model_path)
    
    prediction = model.predict([features])
    return prediction[0]
