#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#!pip install mplfinance
#!pip install opendatasets


# # Libraries

# In[ ]:


# Basic libraries
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

# For processing
import math
import random
import datetime as dt
import matplotlib.dates as mdates

# For visualization
import matplotlib.pyplot as plt


# Libraries for model training
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import  train_test_split
from keras.models import Sequential
from keras.layers import SimpleRNN, Dense, Dropout
from keras.callbacks import ModelCheckpoint, EarlyStopping
from sklearn.metrics import mean_squared_error
from keras.layers import LSTM


# #Load Data

# In[ ]:


df=pd.read_csv('/content/weatherHistory.csv')
df.head()


# In[ ]:


df = df.loc[:, ['Formatted Date','Temperature (C)']]


# In[ ]:


df.sample(5)


# # EDA DF

# In[ ]:


df.reset_index(inplace=True)


# In[ ]:


df.isnull().sum()


# In[ ]:


df.info()


# In[ ]:


df.describe(include='all')


# In[ ]:


df.sample(5)


# #Visualization
# 

# In[ ]:


tdata  = df.set_index('Formatted Date')
tdata.index = pd.to_datetime(tdata.index,  utc=True)
tdata = tdata.resample('D').mean()

tdata = tdata.asfreq('D')


# In[ ]:


plt.figure(figsize=(15, 6))
plt.plot(tdata['Temperature (C)'])
plt.title('Temperature (C) Over Time')
plt.xlabel('Formatted Date')
plt.ylabel('Temperature (C)')
plt.xticks(rotation=45)
plt.grid(True)
plt.show()


# In[ ]:


window = 30
plt.figure(figsize=(15, 6))
plt.plot( df['Temperature (C)'], label='Temperature (C)', linewidth=2)
plt.plot( df['Temperature (C)'].rolling(window=window).mean(), label=f'{window}-Day Moving Avg', linestyle='--')
plt.title(f'Temperature (C) and {window}-Day Moving Average')
plt.xlabel('Formatted Date')
plt.ylabel('Temperature (C)')
plt.xticks(rotation=45)
plt.legend()
plt.grid(True)
plt.show()


# ## Preprocessing

# In[ ]:


new_df = df.reset_index()['Temperature (C)']


# In[ ]:


# df['Month'] = df['Formatted Date'].dt.month
# df['Formatted Date'] = pd.to_datetime(df['Formatted Date'])

# monthly_average = df.groupby('Month')['Temperature (C)'].mean()

# plt.figure(figsize=(15, 6))
# plt.plot(monthly_average.index, monthly_average.values, marker='o')
# plt.title(f'Monthly {new_df}')
# plt.xlabel('Months')
# plt.ylabel('Average Temperature (C)')
# plt.xticks(range(1, 13), ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
# plt.grid(True)
# plt.show()


# ## Normalize the values

# In[ ]:


values_to_scale = df['Temperature (C)'].values.reshape(-1, 1)

scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(values_to_scale)


# ## Data Splitting

# In[ ]:


train_size = int(len(scaled_data) * 0.8)
train_data, test_data = scaled_data[:train_size], scaled_data[train_size:]


# # Define the window (past time steps)

# In[ ]:


n_past = 60

X_train, y_train = [], []
for i in range(n_past, len(train_data)):
    X_train.append(train_data[i - n_past:i, 0])
    y_train.append(train_data[i, 0])
X_train, y_train = np.array(X_train), np.array(y_train)

X_test, y_test = [], []
for i in range(n_past, len(test_data)):
    X_test.append(test_data[i - n_past:i, 0])
    y_test.append(test_data[i, 0])
X_test, y_test = np.array(X_test), np.array(y_test)


# In[ ]:


print("Training set size:-")
print(X_train.shape), print(y_train.shape)
print("\n")
print("Testing set size:-")
print(X_test.shape), print(y_test.shape)


# In[ ]:


X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], 1)
X_test = X_test.reshape(X_test.shape[0], X_test.shape[1], 1)


# ## Modeling

# In[ ]:


model = Sequential()

model.add(SimpleRNN(units=100, return_sequences=True, input_shape=(X_train.shape[1], 1)))
model.add(Dropout(0.2))

model.add(SimpleRNN(units=50, return_sequences=True))
model.add(Dropout(0.2))

model.add(SimpleRNN(units=50))
model.add(Dropout(0.2))

model.add(Dense(units=1))
model.summary()


# In[ ]:


model.compile(loss='mean_squared_error',optimizer='adam')


# In[ ]:


early_stopping = EarlyStopping(monitor='val_loss', patience=7, restore_best_weights=True)

model.fit(X_train, y_train,
          validation_data=(X_test,y_test),
          epochs=5,
          batch_size=100,
          verbose=1,
          callbacks= [ early_stopping])


# In[ ]:


train_predict=model.predict(X_train)
test_predict=model.predict(X_test)


# In[ ]:


train_predict=scaler.inverse_transform(train_predict)
test_predict=scaler.inverse_transform(test_predict)


# In[ ]:


print(math.sqrt(mean_squared_error(y_train,train_predict)))
print(math.sqrt(mean_squared_error(y_test,test_predict)))


# ## Visualization of results

# In[ ]:


look_back = 30

trainPredictPlot = np.empty_like(df)
trainPredictPlot[:] = np.nan

trainPredictPlot[look_back:len(train_predict)+look_back] = train_predict

testPredictPlot = np.empty_like(df,dtype=float)
testPredictPlot[:] = np.nan

test_start = len(df) - len(test_predict)

testPredictPlot[test_start:] = test_predict

original_scaled_data = scaler.inverse_transform(scaled_data)

plt.figure(figsize=(15, 6))
plt.plot(original_scaled_data, color='black', label=f"Actual Temperature (C)")
plt.plot(trainPredictPlot, color='red', label=f"Predicted  Temperature (C)(train set)")
plt.plot(testPredictPlot, color='blue', label=f"Predicted Temperature (C)(test set)")

plt.title(f" Temperature (C)")
plt.xlabel("time")
plt.ylabel(f"Temperature (C)")
plt.legend()
plt.show()


# In[ ]:


last_sequence = X_test[-1]


last_sequence = last_sequence.reshape(1, n_past, 1)
predictions_next_15_days = []
for _ in range(15):
    next_day_prediction = model.predict(last_sequence)
    predictions_next_15_days.append(next_day_prediction[0, 0])
    last_sequence = np.roll(last_sequence, -1, axis=1)
    last_sequence[0, -1, 0] = next_day_prediction

predictions_next_15_days = scaler.inverse_transform(np.array(predictions_next_15_days).reshape(-1, 1))

print("Predictions for the next 15 days:")
for i, prediction in enumerate(predictions_next_15_days, start=1):
    print(f"Day {i}: sales = {prediction[0]}")


# In[ ]:


plt.figure(figsize=(10, 5))
plt.plot(predictions_next_15_days, marker='*', linestyle='-', color='blue')
plt.title(f'Predicted Temperature (C) for Next 15 Days')
plt.xlabel('Days')
plt.ylabel('Temperature (C)')


plt.xticks(ticks=range(15), labels=[f'Day {i+1}' for i in range(15)], rotation=45)
plt.grid(True)
plt.tight_layout()
plt.show()


# 
