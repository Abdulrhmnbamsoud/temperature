
from flask import Flask, request, jsonify, render_template
import joblib
import os
import pandas as pd

app = Flask(__name__)

# Simple route to verify Flask is working
@app.route('/')
def home():
    return render_template('index.html')

# Load the trained model
model_path = os.path.join(os.path.dirname(__file__), '../models/final_model.joblib')
model = joblib.load(model_path)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Extract the JSON data from the request
        data = request.get_json()

        # Convert the JSON data into a pandas DataFrame
        df = pd.DataFrame(data)

        # Perform the prediction
        prediction = model.predict(df)

        # Return the prediction as a JSON response
        return jsonify({'prediction': prediction.tolist()})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    prediction = None
    if request.method == 'POST':
        try:
            # Extract form data
            features = request.form.to_dict(flat=True)
            df = pd.DataFrame([features])

            # Perform the prediction
            prediction = model.predict(df)[0]
        except Exception as e:
            prediction = f"Error: {str(e)}"

    return render_template('dashboard.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True, port=5001)
